// exercice 1



// exercice 2

var fruits = ["🍓", "🍊", "🍉", "🥝"];



// exercice 5





