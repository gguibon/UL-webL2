<?php




// exercice 5



?>