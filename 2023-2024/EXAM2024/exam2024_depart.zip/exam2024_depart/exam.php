<?php

// exercice 3



// exercice 4


?>