// exercice 1

var moi = {
	"nom": "Guibon",
	"prenom": "Gaël",
	"numeroEtudiant": 1234,
	"fruitPrefere": "litchi"
};

console.log(moi);

// exercice 2

var fruits = ["🍓", "🍊", "🍉", "🥝"];

function afficherMagasin() {
	var magasin = document.querySelector("#magasin");
	magasin.innerText = fruits.join(" ");
}

function afficherBoutons() {

	var boutonsFruits = document.querySelector("#boutonsFruits");
	boutonsFruits.innerHTML = "";

	for (let i = 0; i < fruits.length; i++) {
		var btn = document.createElement("button");
		btn.innerText = fruits[i];
		btn.addEventListener('click', function (e) {
			ajouterFruit(e);
		});
		boutonsFruits.appendChild(btn);
	}
}

function ajouterFruit(e) {
	var boutonClique = e.target;
	var fruitClique = boutonClique.innerText;
	var indexFruitClique = fruits.indexOf(fruitClique);
	
	var fruit = fruits.splice(indexFruitClique, 1);
	var cible = document.querySelector("#panier");
	cible.innerText = cible.innerText + " " + fruit;

	afficherBoutons();
}

afficherMagasin();
afficherBoutons();

// exercice 5

function insererFruit(data) {

	var cible = document.querySelector("#panneauFruits");
	cible.innerHTML = "";
	
	for (let i = 0; i < data.length; i++) {
		var div = document.createElement("div");
		var img = document.createElement("img");
		img.setAttribute("src", data[i]['img']);
		img.setAttribute("height", 75);
		var p = document.createElement("p");
		p.innerText = data[i]["description"];
		var vote = document.createElement("p");
		vote.innerText = "votes : " + data[i]["votes"];
		var btn = document.createElement("button");
		btn.innerText = "voter";
		btn.addEventListener("click", function (e) {
			envoyerVoteAuServeur(data[i]["nom"]);
		});

		div.appendChild(img);
		div.appendChild(p);
		div.appendChild(vote);
		div.appendChild(btn);
		cible.appendChild(div);
	}

}

async function recupDonneesServeur() {
	var response = await fetch("/exam2024/api_exam.php");
	console.log('response', response);
	if (response.ok) {
		var data = await response.json();
		console.log('data', data);
		insererFruit(data);
	} else{
		console.log("Oh nooo~")
	}
}

async function envoyerVoteAuServeur(nom){
	var data = {"vote": nom};

	var myHeaders = new Headers();
	myHeaders.append('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');

	var config = {
		method: 'POST',
		headers: myHeaders,
		'body': JSON.stringify(data)
	};

	let response = await fetch("/exam2024/api_exam.php", config);

	if (response.ok) {
		var data = await response.json();
		console.log('data', data);
		insererFruit(data);
	} else {
		alert("oops");
	}
}

recupDonneesServeur();



