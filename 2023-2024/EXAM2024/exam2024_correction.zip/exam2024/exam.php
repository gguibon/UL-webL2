<?php

// exercice 3

function fruitFamily($fruit) {
	$family = array(
		"noyau" => array(
			"description" => "fruits à noyau",
			"instances" => array("prune", "pêche", "cerise")
		),
		"pepin" => array(
			"description" => "fruits à pépin",
			"instances" => array("pomme", "poire", "raisin")
		),
		"baie" => array(
			"description" => "baies et fruits rouges",
			"instances" => array("myrtille", "groseille", "fraise")
		),
		"agrume" => array(
			"description" => "agrumes",
			"instances" => array("citron", "orange", "mandarine")
		),
		"coque" => array(
			"description" => "fruits à coque",
			"instances" => array("noix", "amande", "noisette")
		),
		"exotique" => array(
			"description" => "fruits exotiques",
			"instances" => array("litchi", "kiwi", "grenade")
		)
	);

	$res = "";

	foreach ($family as $k => $v) {
		if (in_array($fruit, $v["instances"])) {
			$res = $v["description"];
		}
	}

	return $res;
}

$fruit = "litchi";
echo "Le $fruit fait partie des " . fruitFamily($fruit) . " !";

// exercice 4

function connect() {
	$db_host = 'localhost';
	$db_user = 'root';
	$db_password = 'root';
	$db_db = 'exam2024';

	$conn = new mysqli($db_host, $db_user, $db_password, $db_db);

	if ($conn->connect_error) {
		echo 'Errno: '.$conn->connect_errno;
		echo '<br>';
		echo 'Error: '.$conn->connect_error;
		exit();
	}

	return $conn;
}


function fruits($conn) {
	$sql = "SELECT * FROM fruits";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$res = "<div><img src=\"{$row['img']}\" height=\"75\"> <p>{$row['description']}</p></div>";
			echo $res;
		}
	}
}

$conn = connect();

fruits($conn);

$conn->close();
?>