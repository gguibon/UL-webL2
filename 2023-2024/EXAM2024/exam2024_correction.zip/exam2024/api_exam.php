<?php

// include 'exam.php';

function connect() {
	$db_host = 'localhost';
	$db_user = 'root';
	$db_password = 'root';
	$db_db = 'exam2024';

	$conn = new mysqli($db_host, $db_user, $db_password, $db_db);

	if ($conn->connect_error) {
		echo 'Errno: '.$conn->connect_errno;
		echo '<br>';
		echo 'Error: '.$conn->connect_error;
		exit();
	}

	return $conn;
}


// exercice 5

function recupDonnees($conn) {
	$res = array();
	$sql = "SELECT * FROM fruits";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			array_push($res, $row);
		}
	}
	echo json_encode($res);
}

function vote($conn, $nom) {
	$statement = $conn->prepare("UPDATE fruits SET votes = votes + 1 WHERE nom = ?;");
	$statement->bind_param("s", $nom);
	$statement->execute();
	
	recupDonnees($conn);
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
	$conn = connect();
	recupDonnees($conn);
	$conn->close();
} 
else if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$conn = connect();
	$_POST = json_decode(file_get_contents('php://input'), true);
	if (count($_POST)) {
		if (isset($_POST["vote"])){
			vote($conn, $_POST["vote"]);
		}
	}
	$conn->close();
}


?>