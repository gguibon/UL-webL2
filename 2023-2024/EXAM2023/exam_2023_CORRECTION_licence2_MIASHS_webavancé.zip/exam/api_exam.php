<?php
header("Content-Type: application/json");

// exercice 9

function connect() {
	$db_host = 'localhost';
	$db_user = 'root';
	$db_password = 'root';
	$db_db = 'exam';

	$conn = new mysqli($db_host, $db_user, $db_password, $db_db);

	if ($conn->connect_error) {
		echo 'Errno: '.$conn->connect_errno;
		echo '<br>';
		echo 'Error: '.$conn->connect_error;
		exit();
	}
	return $conn;
}

function findOneRandom($conn) {
	$sql = "SELECT * FROM chiens ORDER BY RAND() LIMIT 1";
	$result = $conn->query($sql);
	$res = array();
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			array_push($res, $row);
		}
	}
	echo json_encode($res);
}

$conn = connect();

if ($_SERVER["REQUEST_METHOD"] == "GET") {
	findOneRandom($conn);
}

// exercice 10

function addDog($conn, $lien) {
	$statement = $conn->prepare("INSERT INTO `exam`.`chiens` VALUES( ? );");
	$statement->bind_param("s", $lien);
	$statement->execute();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$_POST = json_decode(file_get_contents('php://input'), true);
	if (count($_POST)) {
		if (isset($_POST["lien"])){
			addDog($conn, $_POST["lien"]);
		}
	}
}

$conn->close();

?>