<?php

// exercice 5

$infos = array(
	"nom"=>"Guibon",
	"prenom"=>"Gaël",
	"age"=>35,
	"parcours"=>"tal"
);


foreach ($infos as $k => $v) { // k v pour key value
	echo $v . "<br>";
}

// exercice 6

$cles = array();
foreach ($infos as $k => $v) {
	array_push($cles, $k);
}

for ($i = count($cles)-1; $i >= 0 ; $i--) {
	echo $infos[$cles[$i]] . "<br>";
}

// exercice 7

echo "Le PHP est exécuté côté serveur ! <br>";

// exercice 8

function connect() {
	$db_host = 'localhost';
	$db_user = 'root';
	$db_password = 'root';
	$db_db = 'exam';

	$conn = new mysqli($db_host, $db_user, $db_password, $db_db);

	if ($conn->connect_error) {
		echo 'Errno: '.$conn->connect_errno;
		echo '<br>';
		echo 'Error: '.$conn->connect_error;
		exit();
	}
	return $conn;
}


function poemes($conn) {
	$sql = "SELECT * FROM poemes";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$poeme = "<h3>{$row['titre']}</h3> {$row['auteur']} <p>{$row['texte']}</p>";
			echo $poeme;
		}
	}
}

$conn = connect();

poemes($conn);

$conn->close();
?>