// exo 1
var nom = "Guibon";
var prenom = "Gaël";
var numeroEtudiant = "1234";
console.log(nom, prenom, numeroEtudiant);

// exo 2
var mesinfos = [nom, prenom, numeroEtudiant];
var infos = mesinfos.join(" ");
console.log(infos);

// exo 3

function repondre(question) {
	var res = "";
	if (question == "Quelle différence entre let et var ?") {
		res = "let n'a de portée que dans le bloc, tandis que var dépend du niveau (fonction, classe, fichier)";
	}else if (question == "Le Javascript est habituellement exécuté de quel côté (client ou serveur) ?") {
		res = "client";
	}else {
		res =  "Maiiis chais pas !";
	}
	return res;
}

var rep = repondre("Quelle différence entre let et var ?");
console.log(rep);

// exo 4

function ajouterEmoji() {
	var cible = document.querySelector("#emoji");
	if (cible.innerHTML == "") {
		var p = document.createElement("p");
		p.innerText = "🐶";
		p.setAttribute("onclick", "retirerEmoji()");
		cible.appendChild(p);
	}
}

function retirerEmoji() {
	var cible = document.querySelector("#emoji");
	cible.innerHTML = "";
}

// exo 9

function insererImage(data) {
	var cible = document.querySelector("#image");
	cible.innerHTML = "";
	var img = document.createElement("img");
	img.setAttribute("src", data["image"]);
	img.setAttribute("height", "200px");
	cible.appendChild(img);
}

async function getChien() {
	var response = await fetch("/exam/api_exam.php");
	console.log('response', response);
	if (response.ok) {
		var data = await response.json();
		insererImage(data[0]);
	}else{
		console.log("Oh nooo~")
	}
}

// exo 10

async function addDog(data){
	var myHeaders = new Headers();
	myHeaders.append('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');

	var config = {
		method: 'POST',
		headers: myHeaders,
		'body': JSON.stringify(data)
	};

	let response = await fetch("/exam/api_exam.php", config);

	if (response.ok) {
		alert("chien ajouté");
	}else {
		alert("oops");
	}
}

document.addEventListener('DOMContentLoaded', function(){
	document.querySelector('.ajaxform').addEventListener('submit', function (e) {
		// empêche l'envoi auto du formulaire vers le serveur
		e.preventDefault();
		var data = Object.fromEntries(new FormData(e.target));

		console.log(data);
		addDog(data);
	  });
});
