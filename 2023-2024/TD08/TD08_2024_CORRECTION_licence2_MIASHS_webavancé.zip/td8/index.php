<!-- indication du type de document de manière explicite -->
<!doctype html>
<!-- ouverture de la balise HTML avec indication de la langue du contenu du site (important pour aider par exemple firefox à trouver la bonne langue pour la traduction) -->
<html lang="en">
	<!-- ouverture de l'entête du document, pour y intégrer les métadonnées -->
	<head>
		<!-- indication d'une métadonnée (meta) avec encodage UTF-8 (important pour prendre en compte les signes diacritiques comme le trema de Gaël) ou le cyrillique, alphabet arabe, hiragana, idéogrammes chinois, hangeul, etc. etc. etc. -->
		<meta charset="utf-8">
		<!-- indication de la métadonnée spécifiant le type d'affichage (ici adapté à l'appareil -- le device --) -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- indication du titre de la page qui apparaîtra dans l'onglet du navigateur -->
		<title>TempleDuSWAG</title>
		<!-- mise en place du favicon, c'est-à-dire l'image qui va apparaître en petit aux côtés du titre de l'onglet du navigateur -->
		<link rel="icon" href="img/logo.png" />
		<!-- import de la feuille de style de bootstrap à distance. Celle-ci est "minifiée" et a donc tout le contenu sur une ligne pour gagner de la place et simplifier le téléchagement -->
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
		<!-- import de la feuille de style dédiée aux icônes de bootstrap -->
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
	<!-- fermeture de l'entête -->
	</head>

	<!-- ouverture de la balise body pour mettre le contenu de la page -->
	<body>

		<!-- mise en place d'une barre de navigation la balise "nav" est une balise HTML 5 qui simplifie le travail des robots analyseurs de sites pour référencement automatique (comme Google, Bing, etc.) -->
		<!-- les classes utilisées proviennent de la feuille de style de bootstrap précédemment chargée dans l'entête -->
		<nav class="navbar navbar-expand-sm bg-light navbar-light fixed-top">
			<!-- ouverture d'un container-fluid, c'est à dire un contenant qui prendra toute la place horizontale disponible -->
			<div class="container-fluid">
				<!-- ouverture d'une liste non ordonnée mais ayant la classe bootstrap pour un affichage déjà défini -->
				<ul class="navbar-nav">
					<!-- mise en place des éléments de liste (list item - li -) avec une classe dédiée aux liens de navigation
					ce lien de navigation renvoie vers # donc vers... cette même page. -->
					<li class="nav-link" href="#">
					<!-- balise de lien avec classe dédiée à l'affichage de la marque (brand). Il est de coutume d'y insérer une image du logo du site.  -->
					<a class="navbar-brand" href="#"><img src="img/logo.png" height="24"></a>
					<!-- fermeture de l'élément -->
					</li>
					<!-- ouverture d'un deuxième élément de liste. Cette fois-ci il s'agit d'un élément classique. Si notre possédait plusieurs rubriques alors nous utiliserions plusieurs éléments comme celui-ci. La classe nv-item indique bien un élément de navigation 🤓 -->
					<li class="nav-item">
						<!-- mise en place dans cet élément d'un lien vers... ce qu'on veut. Ici vers la même page. -->
						<a class="nav-link active" href="#"><i class="bi bi-house-fill"> Home</i></a>
					</li>
				</ul>
			</div>
		</nav>

		<!-- maintenant nous nous occupons de mettre en place un petit espace de présentation.
		ici nous utilisons encore un contenant (container) prenant tout l'espace horizontal mais avec un texte centré. Par texte centré, il faut comprendre "contenu centré". C'est pourquoi l'image est également... centrée 😃 -->
		<!-- nous utilisons la balise style car il s'agit du seul changement de style de tout notre site. Si nous en avions plusieurs nous aurions évidemment créé notre propre feuille de style externe (un fichier swag.css par exemple). Le margin-top signifie une marge haute décalant l'ensemble vers le bas de 80 px. Ce qui correspond à la taille standard d'une barre de navigation en bootstrap. -->
		<div class="container-fluid text-center" style="margin-top:80px">
			<!-- on met notre magnifique logo. Notez que ce logo est une provient de https://fr.freepik.com/vecteurs-libre/creation-logo-magasin-vetements-design-plat_28917394.htm#query=vetements%20logo&position=1&from_view=keyword&track=ais
			Je l'ai rapidement modifié pour ajouter le nom de notre marque.
			pour correctement créditer le créateur il faudrait ajouter, quelque part dans la page :
			Image de <a href="https://fr.freepik.com/vecteurs-libre/creation-logo-magasin-vetements-design-plat_28917394.htm#query=vetements%20logo&position=1&from_view=keyword&track=ais">Freepik</a> -->
			<img src="img/logo.png" height="200">
			<!-- une balise de paragraphe -->
			<p>Bienvenue dans le super site des étudiants en L2 MIASHS 😊</p> 
		</div>

		<!-- ouverture de la balise PHP pour que le php soit pris en compte -->
		<?php 
			// maintenant nos commentaires sont comme en java et javascript avec //. Il ne s'agit plus d'un espace HTML 😜
			// indication des informations de connexion
			$db_host = 'localhost'; // l'hôte. Si hébergé sur mon serveur perso, ce serait gguibon.fr
			$db_user = 'root'; // nom de l'utilisateur de la bdd (base de données - bdd). 'root' est la valeur par défaut
			$db_password = 'root'; // mot de passe de la bdd. Les installations on généralement 'root' comme mot de passe par défaut. MAIS si vous utilisez Xampp alors ce mot de passe par défaut sera vide. Il faudrait utiliser la ligne suivante
			// $db_password = ''; // pour Xampp
			$db_db = 'produits'; // nom de la base de données
			$db_port = 8889; // numéro de port. 8889 sous mac par défaut. 3306 sous windows / Xampp etc. regardez la configuration dans la fenêtre de l'outil utilisé. Ce port est celui indiqué pour mysql / base de données

			// utilisons la classe mysqli avec ces informations pour créer une nouvelle instance de cette classe et assigner son contenu dans une variable nommée $conn
			// en d'autres termes, créons un objet de connexion 😊
			$conn = new mysqli($db_host, $db_user, $db_password, $db_db);

			// Vérification de la connexion
			if ($conn->connect_error) {
				// envoi d'un message de fin (die) pour arrêter le script
				// et envoyer un message d'erreur
				die("Connexion ratée U_u : " . $conn->connect_error);
			}

			/**
			 * Fonction dédiée à trouver tous les éléments
			 * trouver = find ; tous = all
			 * cette nomenclature suit la logique de Spring Boot en Java. Mais vous pouvez en utiliser une autre.
			 * findAll, findBy, findByID, findByName, etc.
			 * @param mysqli $conn l'objet de connexion mysqli
			 * @return array[] un tableau de tableaux associatifs
			 */
			function findAll($conn) {
				// création de la  requête SQL toute simple. Il n'est pas possible de faire une requête SQL plus simple que celle-ci 🤣
				$sql = "SELECT * FROM vetements";
				// utilisation de la méthode de requêtage (query()) de l'objet de connexion pour exécuter la requête SQL et mettre son résultat dans la variable $result. attention, cette variable $result est désormais un type de données particulier qu'il convient de mettre dans un format plus habituel
				$result = $conn->query($sql);
				// création d'un tableau vide qui va recevoir le contenu dans un nouveau format
				$data = [];
				// vérification de la longueur du résultat, comme ça, pas d'erreur en cas de contenu vide. Et on peut adapter le comportement. num_rows est donc bien une propriété publique de l'instance $result
				if ($result->num_rows > 0) {
					// SI il y a quelque chose on utilise la méthode fetch_assoc() qui permet de transformer chaque itération de résultat en tant que tableau associatif. Ici nous mappons ce résultat dans une variable $row pendant la boucle while (qui vérifie et continue tant que c'est possible et qui va donc passer sur tous les résultats obtenus)
					while($row = $result->fetch_assoc()) {
						// on pousse le tableau associatif actuel en fin de tableau $data
						array_push($data, $row);
					}
				} else {
					echo "Aucun résultat 😐";
				}
				// on retourne le tabelau de tableaux associatifs enfin utilisable normalement
				return $data;
			}

			// maintenant que la fonction est définie. Nous pouvons simplement l'appeler (i.e. l'utiliser) et ne plus se tracasser avec du SQL ou autres. On met le résultat dans une variable. Attention à la portée des variables : cette nouvelle variable $data n'est pas celle présente dans la fonction findAll ! Elle contient bien les mêmes données donc j'ai gardé le même nom pour bien garder cela en tête
			$data = findAll($conn);

			// ne jamais oublier de fermer correctement la connexion.
			$conn->close();

		// on sort de PHP et on retourne dans du HTML classique
		?>

		<!-- création d'un contenant normal, il ne prendra pas toute la largeur de la page
		mt-5 signifie margin-top 5 donc un niveau de marge haute sur une échelle de 1 à 5 dans bootstrap -->
		<div class="container mt-5">
			<!-- ouverture de la rangée - row en anglais - (pour placer nos éléments dans un quadrillage de la page sous forme de grille) -->
			<div class="row">
				<!-- ici nous voulons rendre l'affichage plus intelligent donc nous entrons dans une zone php -->
				<?php
					// le HTML en PHP n'est rine d'autre qu'une chaîne de caractères. Contrairement au Javascript dans lequel on peut réellement avoir des objets du DOM en mémoire. Nous devons donc maîtriser la manipulation des chaînes de caractères.
					// ici nous créons une variable $nbres (nombres) dans laquelle nous mettons le réusltat de la concaténation (opérateur . ) de deux chaines de caractères et d'un entier. count($data) donne un entier qui sera automatiquement transformé en chaine de caractères. Pratique, mais pas disponible pour tous les types de données.
					// attention pour que php analyse le contenu de cette string il faut impérativement utiliser les guillemets doubles en début et en fin de string (autrement appelé un délimiteur de string)
					$nbres = "<div class='col-sm-4'>
						<h5>". count($data) ." produits trouvés</h5>
					</div></div>";
					// maintenant que nous avons créé ce HTML en forme de String. Nous devons l'afficher.
					echo $nbres;
					// passons maintenant à la mise en place d'une rangée qui contiendra tous les éléments de notre base de données
					// il s'agit d'une rangée (row) avec un effet de gouttière (gutter, un espacement entre éléments) sur l'abscisse (x) - donc gx - et un autre sur l'ordonnée (y) - donc gy -. Comme précédement ces gouttières ont un niveau de 1 à 5 en bootstrap : gx-5 gy-5
					// comme cette string est purement littérale et n'a pas besoin d'être analysée par php nous pouvons utiliser au choix les guillemets doubles ou simples
					echo '<div class="row gx-5 gy-5">';

					// nous itérons sur tous les tabelaux associatifs représentant nos données issus de la bdd
					for ($i = 0; $i < count($data); $i++) {
						// ici considérez tout ce qu'on fait comme un POUR CHAQUE élément de ma BDD
						// création d'une string vide qui acceptera le contenu HTML de l'icône de genre
						$genderIcon = "";
						// si le genre de destination du produit est "Women" alors je donne l'icône avec le signe adéquat
						if ($data[$i]['gender'] == "Women"){ 
							$genderIcon = "<i class='bi bi-gender-female'></i>"; 
						} else { // sinon je donne l'autre signe adéquat 
							$genderIcon = '<i class="bi bi-gender-male"></i>';  
						} 

						// pour la représentation de notre carte, nous reprenons le contenu HTML créé manuellement pour un élément en modifiant le contenu par les valeurs automatique du tableau associatif en cours (car n'oubliions pas que nous sommes dans une boucle for hein !)
						// comme vous le voyez, je mets tout dans une variable $card (une carte)
						// l'usage de la syntaxe avec accolades {$data[$i]['id']} permet de ne pas avoir à échapper de nombreux guillemets doubles.
						$card = "
						<div class='col-sm-4'>
							<div class='card text-bg-light'>
								<img class='card-img-top' src='img/vetements/{$data[$i]['id']}.jpg' alt='Card image cap'>
								<div class='card-body'>
									<h4 class='card-title'>{$data[$i]['productDisplayName']}</h4>
									<p class='card-text'>
										<span class='badge bg-secondary'>{$data[$i]['articleType']}</span>
										<span class='badge bg-secondary'>{$data[$i]['baseColour']}</span>
										<span class='badge bg-dark'>{$data[$i]['year']}</span>
										<span class='badge bg-secondary'>$genderIcon</span>
									</p>
								</div>
							</div>
						</div>";

						// maintenant, nous pouvons afficher cette carte
						echo $card;
						// et nous passerons donc à la ligne suivante de notre base de données (voir les lignes dans phpmyadmin), ligne ici représentée par un tableau associatif :) jusqu'à la dernière ligne
					}

				// on quitte l'espace php pour revenir à de l'HTML 
				?>
			<!-- fermeture de la rangée bootstrap -->
			</div>
		<!-- fermeture du contenant bootstrap -->
		</div>
		
		<!-- import du javascript distant associé à bootstrap. il sera mis en cache dans votre navigateur. bootstrap est essentiellement du CSS mais certains comportements utilisent du javascript. Cette version est la version minifiée (tout sur une ligne) -->
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
	
	<!-- fermeture de la balise du corps (body) de la page -->
	</body>
<!-- fermeture de la balise de la page html -->
</html>
