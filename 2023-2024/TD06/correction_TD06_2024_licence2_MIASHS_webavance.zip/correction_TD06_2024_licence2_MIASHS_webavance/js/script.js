// variable globale qui nous sert à connaître l'ID de l'image actuelle
var imgId = null;

/**
 * fonction pour créer une image en mémoire
 * @param {string} imgPath : chemin relatif de l'image
 * @returns {Object} : object DOM en mémoire
 */
function createImage(imgPath) {
	var img = document.createElement("img");
	img.setAttribute("height", 200);
	img.setAttribute("src", imgPath);
	return img;
}

/**
 * fonction créant une URL à partir de l'identifiant de l'image et des choix de l'utilisateur
 * @param {Object} choices : choix de l'utilisateur, simple tableau associatif
 * @param {string} imgId : identifiant du chat et donc aussi de son image
 * @returns {string} : URL
 */
function buildUrl(choices, imgId) {
	var baseUrl = "https://cataas.com/cat";

	// on ajoute l'identifiant du chat
	baseUrl = baseUrl + "/" + imgId;

	// si un texte est donné on l'ajoute après /says/ 
	if (choices["text"].length > 0) {
		baseUrl = baseUrl + "/says/" + choices["text"];
	}

	// on créer les parmètres de l'URL. Si les valeurs sont nulles alors ces paramètres seront
	// invalides et donc automatiquement ignorés par le serveur
	baseUrl = baseUrl + "?fontSize=" + choices["fontSize"] + "&fontColor=" + choices["fontColor"];
	// toujours pratique de voir quelle URL nous avons finalement conçu
	console.log(baseUrl); 
	
	return baseUrl;
}

/**
 * fonction asynchrone permettant de changer l'image.
 * Pour cela, elle requête le serveur uniquement si on souhaite obtenir un nouveau chat
 * aléatoirement. Autrement, on utilise l'identifiant du chat actuel.
 * @param {string} textOnly : si ce paramètre est donné, alors on utilise l'identifiant du chat actuel et on ne demande pas de nouveau chat
 */
async function changeImage(textOnly) {
	
	// on récupère le formulaire dans le DOM
	var form = document.querySelector("#miaouForm");
	// on analyse ce formulaire pour en obtenir les données
	let formData = new FormData(form);
	// on affiche ce format temporaire pour info
	console.log("formData", formData);

	// on transforme ce format temporaire en un object classsique (tableau associatif)
	let userChoices = Object.fromEntries(formData);
	// on affiche ce tableau associatif pour info
	console.log("userChoices", userChoices);

	// on récupère le lieu où on veut mettre le résultat dans le DOM
	var resultView = document.querySelector("#resultView");
	// on supprime son contenu au cas où il aurait déjà une image
	resultView.innerHTML = "";
	// on créer une image en mémoire
	var waiting = document.createElement("img");
	waiting.src = "img/loading.gif"; // avec le GIF de chargement
	resultView.appendChild(waiting); // qu'on ajoute au DOM ici

	// vérifier cela évite d'avoir à toujours donner ce parmaère. S'il n'est pas donné, il est null
	// cela crée donc une sorte de paramètre optionnel 😉
	if (textOnly != null) {
		// si le textOnly est donné alors on se contente de créer l'url
		url = buildUrl(userChoices, imgId);
	} else {
		// sinon, on demande un nouveau chat en requêtant l'API
		// n'oublions pas de préciser les paramètres de la requête
		let response = await fetch("https://cataas.com/cat", 
			{
				mode: "cors", // pour le cross origin, fourni par défaut
				method: "GET", // GET fait par défaut
				headers: {"accept": "application/json"} // les entêtes. ici on en a qu'une, l'entête "accept" et sa valeur
			}
		);

		// on transforme la réponse en json
		let data = await response.json();

		// si le statut de la réponse est 200 (ok)
		if (response.ok) {
			// alors on prend l'identifiant du chat
			imgId = data["_id"];
			// et on construit une URL avec cet identifiant et les choix de l'utilisateur
			url = buildUrl(userChoices, imgId);
		// sinon
		} else {
			// on donne une url d'image d'erreur
			url = "https://cdn.pixabay.com/photo/2017/02/12/21/29/false-2061132_640.png";
			// et affiche un petit chat effrayé par l'erreur. Pauvre petit chat !
			console.log("error 🙀");
		}
	}
	
	// enfin, on créer l'image en mémoire
	var imageObject = createImage(url);
	// on vide encore le point d'ancrage. Car on veut remplacer l'image de chargement
	resultView.innerHTML = "";
	// et on y insère l'image dans le DOM
	resultView.appendChild( imageObject );
	
}

