// exo 1
var nom = "Guibon";
var prenom = "Gaël";
var numeroEtudiant = "1234";
console.log(nom, prenom, numeroEtudiant);

// exo 2

var boissons = {"bubbletea": "🧋", "café": "☕️", "cocktail": "🍹", "thé": "🍵"};
console.log(boissons["café"]);

// exo 3

// voici une approche plus propre mais vous pouviez aussi simplement les mettre à la main dans le HTML
for (const [k, v] of Object.entries(boissons)) {
	var btn = document.createElement("button");
	btn.innerText = k;
	btn.setAttribute("onclick", `ajouterEmoji("${k}")` ); // aussi possible avec "ajouterEmoji(\"" + k + "\")"
	var buttons = document.querySelector("#buttons");
	buttons.appendChild(btn);
}

function ajouterEmoji(key) {
	var cible = document.querySelector("#emoji");
	cible.innerHTML = ""; // on vide la div
	cible.innerText = boissons[key];
}

// exo 6

function insererImage(data) {
	var cible = document.querySelector("#image");
	cible.innerHTML = "";
	var img = document.createElement("img");
	img.setAttribute("src", data["image"]);
	img.setAttribute("height", "200px");
	cible.appendChild(img);
}

async function getBoisson() {
	var response = await fetch("/rattrapage/api_rattrapage.php");
	console.log('response', response);
	if (response.ok) {
		var data = await response.json();
		insererImage(data[0]);
	}else{
		console.log("Oh nooo~")
	}
}
