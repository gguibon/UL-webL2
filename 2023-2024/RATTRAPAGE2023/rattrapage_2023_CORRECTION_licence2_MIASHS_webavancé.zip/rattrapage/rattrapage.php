<?php

// exercice 4

$infos = array(
	"nom"=>"Guibon",
	"prenom"=>"Gaël",
	"age"=>35,
	"parcours"=>"tal"
);


foreach ($infos as $k => $v) { // k v pour key value
	echo $v . "<br>";
}

// exercice 5

function connect() {
	$db_host = 'localhost';
	$db_user = 'root';
	$db_password = 'root';
	$db_db = 'rattrapage';

	$conn = new mysqli($db_host, $db_user, $db_password, $db_db);

	if ($conn->connect_error) {
		echo 'Errno: '.$conn->connect_errno;
		echo '<br>';
		echo 'Error: '.$conn->connect_error;
		exit();
	}
	return $conn;
}


function musiques($conn) {
	$sql = "SELECT * FROM musiques";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$musique = "<h3>{$row['titre']}</h3> <p>{$row['style']} | {$row['artiste']}</p>";
			echo $musique;
		}
	}
}

$conn = connect();

musiques($conn);

$conn->close();
?>