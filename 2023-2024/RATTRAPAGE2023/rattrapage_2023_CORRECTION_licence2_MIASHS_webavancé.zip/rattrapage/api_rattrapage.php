<?php
header("Content-Type: application/json");

// exercice 6

function connect() {
	$db_host = 'localhost';
	$db_user = 'root';
	$db_password = 'root';
	$db_db = 'rattrapage';

	$conn = new mysqli($db_host, $db_user, $db_password, $db_db);

	if ($conn->connect_error) {
		echo 'Errno: '.$conn->connect_errno;
		echo '<br>';
		echo 'Error: '.$conn->connect_error;
		exit();
	}
	return $conn;
}

function findOne($conn) {
	$sql = "SELECT * FROM boissons LIMIT 1";
	$result = $conn->query($sql);
	$res = array();
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			array_push($res, $row);
		}
	}
	echo json_encode($res);
}

$conn = connect();

if ($_SERVER["REQUEST_METHOD"] == "GET") {
	findOne($conn);
}

$conn->close();

?>