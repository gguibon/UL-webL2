<?php

// {"nom": "Gaël"}
header("Content-Type: application/json");
$donneesAFournir = array("nom"=>"Gaël");
echo json_encode($donneesAFournir);

?>