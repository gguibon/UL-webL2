async function demanderNom() {
	var reponse = await fetch("/ajax/api.php");
	console.log("response", reponse);
	if (reponse.ok) {
		var donnees = await reponse.json(); // {"nom": "Gaël"}
		console.log("donnees", donnees);
		var nom = donnees["nom"]; // "Gaël"
		console.log("nom", nom);
		var cible = document.getElementById("nom");
		cible.innerText = nom;
	}else{
		alert("ERROR 😫");
	}
}