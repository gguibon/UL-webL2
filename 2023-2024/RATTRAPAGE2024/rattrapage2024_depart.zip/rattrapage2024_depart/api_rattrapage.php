<?php

// exercice 4

?>