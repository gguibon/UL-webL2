// exercice 1



// exercice 2



var filtres = ['boisson', 'plat', 'tous'];


// exercice 4
