<?php

// exercice 3

?>