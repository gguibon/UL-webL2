<?php

// exercice 4

function connect() {
	$db_host = 'localhost';
	$db_user = 'root';
	$db_password = 'root';
	$db_db = 'rattrapage2024';

	$conn = new mysqli($db_host, $db_user, $db_password, $db_db);

	if ($conn->connect_error) {
		echo 'Errno: '.$conn->connect_errno;
		echo '<br>';
		echo 'Error: '.$conn->connect_error;
		exit();
	}

	return $conn;
}


function recupDonnees($conn, $type = NULL) {
	$res = array();
	if ($type === NULL) {
		$sql = "SELECT * FROM recettes";
	} else {
		$sql = "SELECT * FROM recettes WHERE type = $type";
	}
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			array_push($res, $row);
		}
	}
	return $result;
}

function afficherRecettes($conn) {
	$sql = "SELECT * FROM recettes";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$res = "<div><h1>{$row['nom']}</h1><h4>{$row['type']}</h4><img src=\"{$row['img']}\" height=\"100\"> <p>{$row['etapes']}</p></div>";
			echo $res;
		}
	}
}

$conn = connect();

afficherRecettes($conn);

$conn->close();
?>