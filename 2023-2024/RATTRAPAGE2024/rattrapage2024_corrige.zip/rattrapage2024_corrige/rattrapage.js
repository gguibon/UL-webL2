// exercice 1

var moi = {
	"nom": "Guibon",
	"prenom": "Gaël",
	"numeroEtudiant": 1234,
	"boissonPreferee": "bubble tea"
};

console.log(moi);

//



var filtres = ['boisson', 'plat', 'tous'];

function afficherBoutons() {
	var boutonsRecettes = document.querySelector("#boutonsRecettes");

	for (let i = 0; i < filtres.length; i++) {
		var div = document.createElement('div');
		var input = document.createElement('input');
		input.setAttribute('type', 'radio');
		input.setAttribute('id', filtres[i]);
		input.setAttribute('name', 'type');
		input.setAttribute('value', filtres[i]);
		var label = document.createElement('label');
		label.setAttribute('for',filtres[i]);
		label.innerText = filtres[i];
		
		input.addEventListener("click", function (e) {
			recupDonneesServeur(filtres[i]);
		});

		div.appendChild(input);
		div.appendChild(label);
		boutonsRecettes.appendChild(div);
	}
}

afficherBoutons();

// exercice 5

function insererRecettes(data) {

	var cible = document.querySelector("#panneauRecettes");
	cible.innerHTML = "";
	
	for (let i = 0; i < data.length; i++) {
		var div = document.createElement("div");
		var nom = document.createElement('h1');
		nom.innerText = data[i]["nom"];
		var img = document.createElement("img");
		img.setAttribute("src", data[i]['img']);
		img.setAttribute("height", 100);
		var p = document.createElement("p");
		p.innerText = data[i]["etapes"];

		div.appendChild(nom);
		div.appendChild(img);
		div.appendChild(p);
		cible.appendChild(div);
	}

}

async function recupDonneesServeur(type) {
	if ((type !== undefined) && (type != 'tous') ) {
		var path = "/rattrapage2024/api_rattrapage.php?type=" + type;
	} else {
		var path = "/rattrapage2024/api_rattrapage.php";
	}
	console.log(path);
	var response = await fetch(path);
	console.log('response', response);
	if (response.ok) {
		var data = await response.json();
		console.log('data', data);
		insererRecettes(data);
	} else{
		console.log("Oh nooo~")
	}
}

recupDonneesServeur();



