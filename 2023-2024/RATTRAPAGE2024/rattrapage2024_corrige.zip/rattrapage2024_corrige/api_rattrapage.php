<?php

// include 'exam.php';

function connect() {
	$db_host = 'localhost';
	$db_user = 'root';
	$db_password = 'root';
	$db_db = 'rattrapage2024';

	$conn = new mysqli($db_host, $db_user, $db_password, $db_db);

	if ($conn->connect_error) {
		echo 'Errno: '.$conn->connect_errno;
		echo '<br>';
		echo 'Error: '.$conn->connect_error;
		exit();
	}

	return $conn;
}



function recupDonnees($conn, $type = NULL) {
	$res = array();
	if ($type === NULL) {
		$sql = "SELECT * FROM recettes";
		$result = $conn->query($sql);
	} else {
		$sql = "SELECT * FROM recettes WHERE type = ?";
		$statement = $conn->prepare($sql);
		$statement->bind_param("s", $type);
		$statement->execute();
		$result = $statement->get_result();
	}
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			array_push($res, $row);
		}
	}
	echo json_encode($res);
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
	$conn = connect();
	if (isset($_GET["type"])){
		recupDonnees($conn, $_GET["type"]);
	} else {
		recupDonnees($conn);
	}
	$conn->close();
}


?>