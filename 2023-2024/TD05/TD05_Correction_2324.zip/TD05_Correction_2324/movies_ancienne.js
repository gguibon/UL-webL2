/**
 * ⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️ ATTENTION ⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️
 * 
 *                                           
 *              ,d                            
 *              88                            
 * ,adPPYba, MM88MMM ,adPPYba,  8b,dPPYba,   
 * I8[    ""   88   a8"     "8a 88P'    "8a  
 *  `"Y8ba,    88   8b       d8 88       d8  
 * aa    ]8I   88,  "8a,   ,a8" 88b,   ,a8"  
 * `"YbbdP"'   "Y888 `"YbbdP"'  88`YbbdP"'   
 *                              88           
 *                              88           
 * 
 * Ce fichier vous montre comment faire l'AJAX avec des HTTPRequest
 * C'est une méthode assez vieille et moins pratique que la méthode moderne. De plus, je n'ai pas autant commenté cette approche que la méthode moderne.
 * 
 * Vous êtes donc invités à vous rendre dans le fichier movies_moderne.js pour avoir le fichier utilisé dans cette correction et l'approche préférentielle.
 * 
 * ⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️⛔️
 */



// Variables to save the previous sorting
var previousSorting = 0;
var NAME = 1;
var RATING = 2;
var NAME_INVERTED = 3;
var RATING_INVERTED = 4;

// Cache
var cache = {};

// -------------------------

// Load the table with no sorting
loadJSONDoc();

// Event listeners
document.getElementById("nameCell").addEventListener("click", function(){
	loadJSONDoc("name");
});
document.getElementById("ratingCell").addEventListener("click", function(){
	loadJSONDoc("rating");
});

// -------------------------

/**
 * Load a JSON document and process its content to fill the movie table.
 * @param {String} sort - the type of sorting
 */
 function loadJSONDoc(sort){
	// Create XMLHttpRequest object (Check browser)
	var xmlhttp;
	if (window.XMLHttpRequest){
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	}
	else{
		// code for IE5 and IE6
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	// URL for the AJAX call
	var AJAXurl = buildUrl(sort);

	// Things to do when a response arrives
	xmlhttp.onreadystatechange = function(){
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200){
			// Parse the response
			var resp = JSON.parse(xmlhttp.responseText);

			// Process the parsed content
			processContent(resp);

			// Update the cache
			cache[AJAXurl] = resp;
		}
	};

	// Is the corresponding JSON response already in cache?
	if (cache && cache[AJAXurl]){
		// Build the table from the cached content
		processContent(cache[AJAXurl]);
		console.log("Loaded from cache.");
	}
	else{
		// AJAX call
		xmlhttp.open("GET", AJAXurl);
		xmlhttp.send();
	}	

	// Update the history
	var state = {previousSorting: previousSorting, AJAXurl: AJAXurl};
	history.pushState(state, null, null);
}

/**
 * Build the URL for making the AJAX request.
 */
function buildUrl(sort){
	var url = "http://gguibon.fr/movies.php";

	// sort by name
	if (sort == "name"){
		//Inverted
		if (previousSorting == NAME){
			url += "?sort=name&inverted=true";
			previousSorting = NAME_INVERTED;
		}
		// Not inverted
		else{
			url += "?sort=name";	  
			previousSorting = NAME;
		}
	}
	
	// sort by rating
	else if (sort == "rating"){
		// Inverted
		if (previousSorting == RATING){
			url += "?sort=rating&inverted=true";
			previousSorting = RATING_INVERTED;
		}
		// Not inverted
		else{
			url += "?sort=rating";
			previousSorting = RATING;
		}
	}

	// Limit the number of lines
	var dropDownSelect = document.getElementById("dropDownSelect");
	var lines = dropDownSelect.options[dropDownSelect.selectedIndex].value;
	if (lines != "all"){
		url += "&limit=" + lines;
	}

	return url;
}

/**
 * Browses the parsed JSON content and update the table accordingly.
 */
 function processContent(resp){
	// Get the table
	var table = document.getElementById("movieTable");

	// Empty the table (without removing the <th> cells)
	while(table.tBodies[0].children.length > 1){
		table.tBodies[0].removeChild(table.tBodies[0].children[1]);
	}

	// Put the new content
	insert(resp, table);
}

/**
 * Insert the specified content (array of movies) in the specified table
 */
 function insert(content, table){
 	var movies = content.movies;
 	for (var i = 0; i < movies.length; i++){
 		var tr = document.createElement("tr");
 		table.tBodies[0].appendChild(tr);

		// Image
		var tdImage = document.createElement("td");
		tr.appendChild(tdImage);
		var img = document.createElement("img");
		img.setAttribute('src', movies[i].image);
		img.setAttribute('alt', 'poster');
		img.className = "imageCell";
		tdImage.appendChild(img);
		
		// Name
		var tdName = document.createElement("td");
		tr.appendChild(tdName);
		var nameTextNode = document.createTextNode(movies[i].name);
		tdName.appendChild(nameTextNode);
		
		// Rating
		var tdRating = document.createElement("td");
		tr.appendChild(tdRating);
		var ratingTextNode = document.createTextNode(movies[i].rating);
		tdRating.appendChild(ratingTextNode);
	}
}

/**
 * The onpopstate function.
 * Set the previous sorting to the one stored in the corresponding state and
 * process the JSON content which corresponds to the stored AJAX url (we assume it is in cache)
 */
 window.onpopstate = function(event) {
 	previousSorting = event.state.previousSorting;
 	processContent(cache[event.state.AJAXurl]);
 };