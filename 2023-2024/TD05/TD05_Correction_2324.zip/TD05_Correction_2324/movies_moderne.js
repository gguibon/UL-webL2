
// Variables pour sauvegarder le tri précédent. Utile pour alterner entre les tri ascendants et descendants (croissants et décroissants) en un seul clic
var previousSorting = 0;
var NAME = 1;
var RATING = 2;
var NAME_INVERTED = 3;
var RATING_INVERTED = 4;

// Variable qui va créer un simili cache. En tant normal ce que nous appelons "cache" est l'usage de fichiers stockés dans l'espace disque de votre ordinateur et réutilisés. Ici, il s'gait simple d'une variable en mémoire RAM (donc pas sur votre disque dur ou SSD)
// cette variable est un tableau associatif vide comme indiqué par {}
var cache = {};

// -------------------------
/**
 * C'est cette fonction asynchrone qui permet de gérer l'appel au serveur et de conditionner l'action une fois une réponse reçue.
 * Elle accepte un paramètre sort (qui signifier "tri" en anglais). Cela permet de choisir sur quelle colonne on va trier. Comme vous pouvez le voir, cette fonction peut être appelée sans paramètre car en Javascript les paramètres sont optionnels par défaut 😉
 * Comme vous pouvez le voir cette fonction est préfixée par "async" pour indiquer qu'il s'agit d'une fonction asynchrone.
 * @param {*} sort 
 */
async function loadJSONDoc(sort){
	// URL (c'est-dire adresse) de l'appel AJAX (asynchrone)
	// nous utilisons la fonction buildUrl() est dédiée à construire l'adresse avec les paramètres dans l'URL
	// (pour rappel un paramètre d'url est par exemple : http://gguibon.fr?nomduparametre1=valeurduparametre1&nomduparametre2=valeurduparametre2 )
	var AJAXurl = buildUrl(sort);

	// on vérifie si le cache (en l'occurrence ici la variable contenue en mémoire RAM) possède déjà le contenu JSON de cet URL
	if (cache && cache[AJAXurl]){
		// SI le contenu est déjà en mémoire ALORS
		// on contruit le tableau, on le rempli à l'aide du contenu déjà présent en mémoire
		processContent(cache[AJAXurl]);
		// on affiche (dans le journal de la console) un message qui indique que le contenu a été chargé à partir de la mémoire
		console.log("Loaded from cache.");
	}else{
		// SINON (donc si le contenu n'est pas déjà en mémoire) ALORS
		// on fait une requête HTTP à l'aide de la fonction fetch() vers l'URL construite
		// vous noterez que le prefixe "await" n'est disponible que dans les fonctions asynchrones (préfixées de async)
		// await permet d'attendre la réponse. Concrètement, cela permet de laisser le navigateur continue les autres processus en attendant (await en anglais) un retour de cette requête. Dès que le retour arrive, la réponse est alors mise dans la variable "response"
		let response = await fetch(AJAXurl);
		// la réponse possède plusieurs éléments: header, statut, contenu, etc. Nous la transformons ainsi en JSON. Mais vous vous demanderez surement pourquoi cette traduction de la réponse au format JSON avec .json() a besoin d'être asynchrone à l'aide de await ? C'est parce que cette analyse peut parfois prendre du temps et n'a donc pas besoin d'être bloquante pour le navigateur (ce qui aurait pour effet de bloquer toute action dans la page web en attendant la fin de l'analyse)
		let dataFromServer = await response.json();
		// maintenant que le contenu est mis au format JSON dans une variable nous passons à la vérification du statut de la réponse. Les statuts sont normalement des codes comme 200 pour OK, 404 pour NOT FOUND, 500 pour erreur serveur, etc. etc. 
		// on peut directement vérifier si ok est true ou false (un booléen donc)
		if(response.ok){
			// SI le statut de la réponse est OK (200) aLORS
			// on fait toute notre panoplie de modification de la page à partir du contenu
			processContent(dataFromServer);
			// puis on met à jour la variable cache pour éviter de faire deux fois le même appel
			cache[AJAXurl] = dataFromServer;
		}else{
			// SINON (donc si le statut n'est pas OK (200)) ALORS
			// on ajoute une entrée au journal de la console
			console.log('error');
			// nous pourrions aussi être très méchant et afficher un popup d'alerte comme ceci
			alert('ERROR 😱😱😱😱😱😱😱😱');
		}
	}

	// Update the history
	// ici quoi qu'il arrive, nous mettons à jour l'historique de la page.
	// nous avons donc une variable state ("état" en anglais) qui est un tableau associatif clé:valeur dans laquelle nous mettons le tri précédent (clé previousSorting) et l'url précédent (clé AJAXurl)
	var state = {previousSorting: previousSorting, AJAXurl: AJAXurl};
	// à l'aide de la variable history déjà présente dans Javascript et dédiée à la gestion de l'historique de la session du navigateur, nous ajoutons un état (pushState -- littéralement "pousserEtat")
	history.pushState(state, null, null);
}


/**
 * Fonction qui construit l'URL en fonction de la valeur du tri demandé, si un tri est bien demandé
 * très utile pour indiquer vers où la requête AJAX doit aller, vers quelle adresse (URL)
 * @param {*} sort le paramètre sort indique le tri (trié sur le nom, ou sur le score par exemple)
 * @returns retourne une super URL toute belle en chaîne de caractères (String)
 */
function buildUrl(sort){
	var url = "http://gguibon.fr/movies.php"; // l'url de base à laquelle on veut ajouter des parmaètres comme ?sort=name

	// tri (sort) des films par nom (name)
	if (sort == "name"){
		// tri inversé si le tri précédent était déjà par nom
		if (previousSorting == NAME){
			url += "?sort=name&inverted=true";
			previousSorting = NAME_INVERTED;
		}
		// tri normal si ce n'était pas le cas
		else{
			url += "?sort=name";	  
			previousSorting = NAME;
		}
	}
	
	// tri par score donné aux films (rating)
	else if (sort == "rating"){
		// tri inversé si le tri précédent était déjà par rating
		if (previousSorting == RATING){
			url += "?sort=rating&inverted=true";
			previousSorting = RATING_INVERTED;
		}
		// tri normal si ce n'était pas le cas
		else{
			url += "?sort=rating";
			previousSorting = RATING;
		}
	}

	// Limiter le nombre de lignes du tableau
	// pour cela nous récupérons le sélecteur à tiroir (dropdownselect) par son identifiant et le mettons dans une variable
	var dropDownSelect = document.getElementById("dropDownSelect");
	// nous récupérons la valeur qui a été choisie parmi toutes les options (5, 10, 15, etc. ici on récupère les options automatiquement) puis on met cela dans une variable
	var lines = dropDownSelect.options[dropDownSelect.selectedIndex].value;
	if (lines != "all"){
		// si la variable n'ets pas égale à "all", c'est-à-dire si cette variable n'indique pas de prendre en compte toutes les lignes du tableau, alors nous utilisons le limiteur pour limiter (:D) le nombre en tant que paramètre ajouté à la requête
		// cela permet de limiter l'accès à la base de données et le traffic de données à récupérer. Donc une requête et une réactivité du site bien plus rapide
		url += "&limit=" + lines;
	}

	return url;
}

/**
 * Browses the parsed JSON content and update the table accordingly.
 */
/**
 * fonction qui parcourt le JSON analysé et met à jour le tableau HTML en fonction de son contenu
 * @param {*} resp paramètre prenant le contenu de la réponse JSON (ce qui rend cette fonction réutilisable)
 */
function processContent(resp){
	// récupère la balise <table> qui possède l'identifiant "movieTable" dans la page HTML et l'assigne à une variable
	var table = document.getElementById("movieTable");

	// Empty the table (without removing the <th> cells)
	// nous vidons désormais le tableau (sans les TH - les entêtes - évidemment). 
	// pour ce faire, nous utilisons une boucle TANTQUE (while) qui va suprimer tous les enfants contenus dans le corps du tableau (<tbody>)
	// ce TANTQUE supprime le contenu TANT QUE le nombre d'enfants dans le tableau est supérieur à 1
	while(table.tBodies[0].children.length > 1){
		table.tBodies[0].removeChild(table.tBodies[0].children[1]);
	}

	// avec notre fonction d'insertion nous insérons désormais tout le nouveau contenu
	// cette logique est la même que pour le jeu de serpents : on efface le contenu puis on remet toutes les nouvelles infos
	insert(resp, table);
}

/**
 * fonction qui insère (insert) le contenu spécifié issu du paramètre "content" dans le tableau issu de la variable "table"
 * @param {*} content tableau associatif contenant le contenu des films
 * @param {*} table tableau présent dans le HTML
 */
function insert(content, table){
	// on récupère le contenu associé à la clé "movies" et on le met dans une variable. Ce contneu est une liste de tableaux associatifs. Chaque tableau associatif représentant les informations d'un film (clés image, name, rating, id)
	var movies = content.movies;
	// pour tous les films (leur tableau associatif respectif)
	for (var i = 0; i < movies.length; i++){
		// on créer une balise <tr> (table row  ou TR), donc une rangée  en mémoire et on l'assigne à la variable tr
		var tr = document.createElement("tr"); // <tr></tr>
		// on réucpère le premier élément du corps du tableau et on ajoute la rangée
		table.tBodies[0].appendChild(tr);

		// Image - on s'occupe de créer la colonne de l'image pour cette rangée
		// on créer la balise TD en mémoire (<td> étant une colonne de tableau)
		var tdImage = document.createElement("td"); // <td></td>
		// on ajoute à la rangée la balise td créée
		tr.appendChild(tdImage);
		// on créer une balise image <img> en mémoire
		var img = document.createElement("img");
		// on lui ajoute deux attributs : l'atrribut src avec le lien de l'image, et son texte à indiquer en cas de non chargement de l'imgae avec l'atrribut alt
		img.setAttribute('src', movies[i].image); // <img src="gguibon.fr/images/imagedufilm.png">
		img.setAttribute('alt', 'poster'); // <img src="gguibon.fr/images/imagedufilm.png" alt="poster">
		// on ajoute à cette balise <img> une classe
		img.className = "imageCell"; // <img src="gguibon.fr/images/imagedufilm.png" alt="poster" class="imageCell">
		// enfin on met cette balise image dans la balise td que nous avions créée
		tdImage.appendChild(img); // <td><img src="gguibon.fr/images/imagedufilm.png" alt="poster" class="imageCell"></td>
		
		// Name - on s'occupe de créer la colonne du nom du film pour cette rangée
		// même principe que pour les images
		var tdName = document.createElement("td"); // <td></td>
		tr.appendChild(tdName);
		// on ajoute un noeud texte (en gros, du contenu textuel direct) qui contient le nom du film numéro i dans la boucle FOR actuelle
		var nameTextNode = document.createTextNode(movies[i].name);
		tdName.appendChild(nameTextNode); // on l'ajoute à <td>, obtenant quelque chose comme : <td>Matrix</td>     par exemple
		
		// Rating - on s'occupe de créer la colonne du score (rating) pour cette rangée
		var tdRating = document.createElement("td"); //<td></td>
		tr.appendChild(tdRating);
		var ratingTextNode = document.createTextNode(movies[i].rating); // <td>4.7</td>    par exemple
		tdRating.appendChild(ratingTextNode); // on l'ajoute au td.

		// vous noterez que dès qu'on a utilisé tr.appendChild() nous avons attaché les éléments à un balise existante et de ce fait elle appraît dans le corps de notre HTML; elle fait partie du DOM (document object model, la hiérarchie du fichier HTML)
	}
}

/**
 * la fonction onpopstate qui, comme vous le voyez, utilise l'autre syntaxe de fonction en Javascript car nous redéfinissons une fonction dans l'objet window
 * Cette fonction assigne le tri précédent à celui indiqué dans l'événement 
 * Elle traite ensuite le contenu à partir du cache pour revenir à l'état précédent de contenu dans le tableau HTML
 * C'est pour cela que vous pouvez cliquer sur le bouton "précédent" dans votre navigateur pour revenir à l'état précédent alors que nous somme toujours resté sur la même page vu qu'il s'agit de requêtes AJAX 😛
 * @param {*} event 
 */
 window.onpopstate = function(event) {
 	previousSorting = event.state.previousSorting;
 	processContent(cache[event.state.AJAXurl]);
 };


// ------------------------- action à faire en arrivant sur la page :)
// charge le tableau sans aucun filtre à l'aide de notre super fonction 💪
loadJSONDoc();