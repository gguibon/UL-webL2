async function maFonction() {
	// l'adresse à laquelle on va envoyer la requête
	var url = "http://gguibon.fr/movies.php";
	// on fait une requête GEt à l'aide de fetch() qui
	// renvoie donc une promise
	// on combine avec await pour attendre de manière asynchrone que
	// la promise soit bien finie
	var response = await fetch(url);

	// regardons cette réponse dans la console
	console.log("réponse", response);

	// on en fait de même avec la méthode .json() de la réponse
	// cette méthode utilise une promise pour permettre
	// un traitement asynchrone du json (qui peut être bien loooooong 😉)
	var data = await response.json();

	// maintenant nos données sont au format JSON
	// donc un tableau associatif
	// affichons cela dans la console 😁
	console.log("data", data);

	// on vérifie le statut de la réponse
	// on peut aussi vérifier avec response.status
	if (response.ok) {
		// maintenant que tout est bien récupéré, on crée une balise p
		var p = document.createElement("p");
		// optionnellement on peut y attribuer le contenu de data au format textuel
		// à l'aide de JSON.stringify()
		// p.textContent = JSON.stringify(data);

		// ou alors on peut y mettre une valeur issue du tableau associatif 😎
		p.textContent = data["movies"][0]["name"];

		// n'oublions pas de l'ajouter au DOM réel 😳
		document.body.appendChild(p); 
	} else {
		// en cas de pépin, on affiche un message dans la console
		console.log("marche pô, oh non~ 😣");
	}
}


// n'oublions pas d'appeler cette fonction, sinon rien ne se passe 🤓
maFonction();